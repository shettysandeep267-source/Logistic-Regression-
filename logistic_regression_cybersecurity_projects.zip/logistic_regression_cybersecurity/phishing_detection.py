import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report

# 1. Load data from the CSV file
df = pd.read_csv("phishing_email_data.csv")

# 2. Separate features (input) and target class (output)
X = df[["url_length", "num_dots", "has_ip_address", "has_https",
        "num_hyphens", "num_at_symbols", "suspicious_keyword_count"]]
y = df["Target_Class"]

# 3. Split data into training (80%) and testing (20%) sets
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# 4. Initialize and train the Logistic Regression model
model = LogisticRegression(max_iter=1000)
model.fit(X_train, y_train)

# 5. Predict on test data and a custom URL-feature example
y_pred = model.predict(X_test)
sample_input = pd.DataFrame([{
    "url_length": 85, "num_dots": 4, "has_ip_address": 1,
    "has_https": 0, "num_hyphens": 3, "num_at_symbols": 1,
    "suspicious_keyword_count": 3
}])
custom_class = model.predict(sample_input)
custom_prob = model.predict_proba(sample_input)

# 6. Display results
print("Test Accuracy:", f"{accuracy_score(y_test, y_pred):.2%}")
print("First 10 Test Predictions:", y_pred[:10])
print("Custom URL predicted class (1 = suspicious/phishing):", custom_class[0])
print(f"Probability of class 1: {custom_prob[0][1]:.2%}")
print("\\nClassification Report:\\n", classification_report(y_test, y_pred))
