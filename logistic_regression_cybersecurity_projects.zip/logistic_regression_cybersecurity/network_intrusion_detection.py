import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report

# 1. Load data from the CSV file
df = pd.read_csv("network_intrusion_data.csv")

# 2. Separate network-flow features and target class
X = df[["duration_seconds", "src_bytes", "dst_bytes", "failed_connections",
        "syn_count", "unique_dst_ports"]]
y = df["Target_Class"]

# 3. Split data into training (80%) and testing (20%) sets
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# 4. Initialize and train the Logistic Regression model
model = LogisticRegression(max_iter=1000)
model.fit(X_train, y_train)

# 5. Predict on test data and a custom network-flow example
y_pred = model.predict(X_test)
sample_input = pd.DataFrame([{
    "duration_seconds": 1.2, "src_bytes": 400, "dst_bytes": 250,
    "failed_connections": 12, "syn_count": 18, "unique_dst_ports": 14
}])
custom_class = model.predict(sample_input)
custom_prob = model.predict_proba(sample_input)

# 6. Display results
print("Test Accuracy:", f"{accuracy_score(y_test, y_pred):.2%}")
print("First 10 Test Predictions:", y_pred[:10])
print("Custom network-flow predicted class (1 = suspicious):", custom_class[0])
print(f"Probability of class 1: {custom_prob[0][1]:.2%}")
print("\\nClassification Report:\\n", classification_report(y_test, y_pred))
