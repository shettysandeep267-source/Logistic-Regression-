# Logistic Regression Cybersecurity Mini-Projects

Four beginner-friendly educational examples using the same workflow:
1. Phishing URL/email feature classification
2. Network intrusion classification from network-flow features
3. Malware-like file classification from static metadata
4. Possible brute-force detection from aggregated authentication logs

## Setup
Install dependencies:
    pip install pandas scikit-learn

Keep each `.py` file in the same folder as its matching `.csv` file.
Run one at a time:
    python phishing_detection.py
    python network_intrusion_detection.py
    python malware_file_classification.py
    python brute_force_detection.py

## Label meaning
For all datasets:
- Target_Class = 0: benign / normal
- Target_Class = 1: suspicious / positive class

## Important limitations
All four CSV datasets are synthetic examples created for learning and code practice.
The models demonstrate the Logistic Regression workflow; their accuracy is not evidence of real-world security performance.
These are not production detection systems:
- Phishing example uses manually supplied URL indicators; it does not parse or inspect email content.
- Network example classifies precomputed flow features; it does not capture live packets.
- Malware example uses metadata only; it does not execute, unpack, or safely analyze files.
- Brute-force example classifies aggregated login-window metrics; it does not monitor a live authentication service.

For real use, train and validate on representative, legally collected, correctly labelled data, evaluate false positives/false negatives, and integrate with approved logging/monitoring systems.
